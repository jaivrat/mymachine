public class Percolation {
   private int mgridSZ;
   private WeightedQuickUnionUF cont;
   private int mBottomSentinelIdx;
   private int mTopSentinelIdx;

   //just for performance
   private int lastIdx;
   
   private int[][] multi; 
   
   private void checkRange(int i, int j)
   {
       if (i < 1 || i > mgridSZ)
       {
           throw new java.lang.IndexOutOfBoundsException();
       }
       
       if (j < 1 || j > mgridSZ)
       {
           throw new java.lang.IndexOutOfBoundsException();
       }
   }
   
   public Percolation(int N)              // create N-by-N grid, with all sites blocked
   {
       if(N<=0)
           throw new java.lang.IllegalArgumentException();
       
       mgridSZ = N;
       cont                = new WeightedQuickUnionUF(mgridSZ*mgridSZ+2); //2 added to hold top and bottom sentinels
       mBottomSentinelIdx  = mgridSZ*mgridSZ;
       mTopSentinelIdx     = mBottomSentinelIdx + 1;
       lastIdx             = mgridSZ -1; //0..N-1
       
       multi = new int[N][N];
   }
   
   public void open(int i, int j)         // open site (row i, column j) if it is not already
   {
       checkRange(i,j);
       //convention
       i = i -1;
       j = j -1;
       
       if (multi[i][j] == 1)
           return;
       
       //open the site
       multi[i][j] = 1; 
       
       //do connections
       int idx = mgridSZ * i + j;
       //System.out.println("Opening linear idx=" + idx );
       
      //explore X+
      if (j+1 <= lastIdx && isOpen(i+1, j+2)) // checking i, j+1
           cont.union(idx, idx+1);
           
       //explore X-
       if (j-1 >= 0 && isOpen(i+1, j)) //checking i,j-1
           cont.union(idx, idx-1);
           
       //explore Y+
       if (i+1 <= lastIdx && isOpen(i+2, j+1)) //check i+1,j
       {
           cont.union(idx, idx + mgridSZ);
       }
       else if (i == lastIdx)
       {       // sentinels to be connected
           cont.union(idx, mTopSentinelIdx);
       }
       
        //explore Y-
       if ( i-1 >= 0 && isOpen(i,j+1))    //check i-1,j
           cont.union(idx, idx - mgridSZ);
       else if (i == 0)
       {       // sentinels to be connected
           cont.union(idx, mBottomSentinelIdx);
       }
   }
   
   public boolean isOpen(int i, int j)    // is site (row i, column j) open?
   {
       checkRange(i,j);
       i = i -1;
       j = j -1;
       return multi[i][j] == 1;
   }
   
   //Does this mean closed ie Full of Opaue - Jai?
   public boolean isFull(int i, int j)    // is site (row i, column j) full?
   {
       checkRange(i,j);
       if(isOpen(i,j) == false)
           return false;
       
       //now the site is open
       i = i - 1;
       j = j - 1;
       
       if(i == lastIdx) //top row not called Full site
           return false;
       
       int idx = mgridSZ * i + j;
       return cont.connected(mTopSentinelIdx,idx);
   }
   
   public boolean percolates()            // does the system percolate?
   {
       return cont.connected(mTopSentinelIdx,mBottomSentinelIdx);
   }
 
   //just for debug print
//   public void debugPrint()
//   {
//       int X = multi.length;
//       int Y = multi[0].length;
//       
//       for(int i=0; i< X; ++i)
//       {
//           for(int j=0; j<Y ; ++j)
//           {
//               if(isOpen(i,j))
//                   System.out.print("O - ");
//               else
//                   System.out.print("X - ");
//           }
//           System.out.println("\n");
//       }
//       
//       System.out.println("**********\n");
//   }
}